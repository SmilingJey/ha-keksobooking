'use strict';

var LOCATION_Y_MIN = 130;
var LOCATION_Y_MAX = 630;

var CARD_TITLES = ['Большая уютная квартира',
  'Маленькая неуютная квартира',
  'Огромный прекрасный дворец',
  'Маленький ужасный дворец',
  'Красивый гостевой домик',
  'Некрасивый негостеприимный домик',
  'Уютное бунгало далеко от моря',
  'Неуютное бунгало по колено в воде'];

var CHECKIN_TIMES = ['12:00', '13:00', '14:00'];
var CHECKOUT_TIMES = ['12:00', '13:00', '14:00'];

var ROOMS_COUNT_MIN = 1;
var ROOMS_COUNT_MAX = 5;

var GUESTS_COUNT_MIN = 1;
var GUESTS_COUNT_MAX = 1000;

var PRICE_MIN = 1;
var PRICE_MAX = 1000;

var getRandomInt = function (min, max) {
  return Math.floor(Math.random() * (max + 1 - min) + min);
};

var generateMockCards = function (count) {
  var mapElement = document.querySelector('.map');
  var mapWidth = mapElement.offsetWidth;

  var cards = [];

  for (var i = 0; i < count; i++) {
    var checkoutIndex = getRandomInt(0, CHECKIN_TIMES.length - 1);
    var checkinIndex = getRandomInt(checkoutIndex, CHECKIN_TIMES.length - 1);
    var locationX = getRandomInt(0, mapWidth);
    var locationY = getRandomInt(LOCATION_Y_MIN, LOCATION_Y_MAX)

    cards.push({
      author: {
        avatar: 'img/avatars/user' + i % 8 + '.png'
      },
      title: CARD_TITLES[i % 8],
      address: locationX + ', ' + locationY,
      price: getRandomInt(PRICE_MIN, PRICE_MAX),
      type: '',
      rooms: getRandomInt(ROOMS_COUNT_MIN, ROOMS_COUNT_MAX),
      guests: getRandomInt(GUESTS_COUNT_MIN, GUESTS_COUNT_MAX),
      checkin: CHECKIN_TIMES[checkinIndex],
      checkout: CHECKOUT_TIMES[checkoutIndex],
      features: '',
      description: '',
      location: {
        x: locationX,
        y: locationY
      }
    });
  }
};

generateMockCards(5);
